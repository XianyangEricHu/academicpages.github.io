import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class AddressBook {

    private static class Contact implements Serializable {
        private static int count = 0;
        private int id;
        private String name;
        private String email;
        private String phone;
        private String notes;

        public Contact(String name, String email, String phone, String notes) {
            this.id = ++count;
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.notes = notes;
        }

        public static int getCount() {
            return count;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getNotes() {
            return notes;
        }

        public void setNotes(String notes) {
            this.notes = notes;
        }
    }

    private static ArrayList<Contact> contacts = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    private static final String FILE_NAME = "data.bin"; // Filename to store and load data
    public static void main(String[] args) {
        loadFromFile();  // Load existing data when starting the program
    
        while (true) {
            showMainWindow();
    
            while (!scanner.hasNextInt()) { // While the input is not an integer
                System.out.println("Invalid input! Please enter a valid number.");
                scanner.nextLine();  // Clear the invalid input
            }
    
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline
    
            switch (choice) {
                case 1:
                    addNewContact();
                    break;
                case 2:
                    searchForContact();
                    break;
                case 3:
                    displayAllContacts();
                    break;
                case 4:
                    saveToFile();  // Save data when quitting the program
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
    

    private static void loadFromFile() {
        try (FileInputStream fis = new FileInputStream(FILE_NAME);
             ObjectInputStream ois = new ObjectInputStream(fis)) {

            contacts = (ArrayList<Contact>) ois.readObject();
            int storedCount = ois.readInt();
            Contact.count = storedCount;

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
        }
    }

    private static void saveToFile() {
        try (FileOutputStream fos = new FileOutputStream(FILE_NAME);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {

            oos.writeObject(contacts);
            oos.writeInt(Contact.getCount());
            System.out.println("Data saved successfully!");

        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    private static void showMainWindow() {
        System.out.println("\nMain Window:");
        System.out.println("====================================");
        System.out.println("Choose one of the following options:");
        System.out.println("(1) Add a new contact");
        System.out.println("(2) Search for contact");
        System.out.println("(3) Display all contacts");
        System.out.println("(4) Quit");
        System.out.print("Enter Your Choice: ");
    }

    private static void addNewContact() {
        System.out.println("Main Window -> Add a new contact window: (Enter the following information)");
        System.out.println("==========================================================================");
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Notes: ");
        String notes = scanner.nextLine();

        Contact contact = new Contact(name, email, phone, notes);
        contacts.add(contact);

        System.out.println("---------------------------------------------------------------------");
        System.out.println("Saved successfully....Press Enter to go back to the Main Window");
        scanner.nextLine();
    }

    private static void searchForContact() {
        while (true) {
            System.out.println("Main Window -> Search for Contact window: (Choose one of the following options)");
            System.out.println("===============================================================================");
            System.out.println("(1) Search by Name");
            System.out.println("(2) Search by Email");
            System.out.println("(3) Search by Phone");
            System.out.println();
            System.out.print("Enter Your Choice: ");
    
            if (scanner.hasNextInt()) {
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline
    
                switch (choice) {
                    case 1:
                        searchByName();
                        return;  // Break out of the loop after valid processing
                    case 2:
                        searchByEmail();
                        return;
                    case 3:
                        searchByPhone();
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 3.");
                        break;
                }
            } else {
                scanner.nextLine();  // Clear invalid input
                System.out.println("Invalid input. Please enter a number between 1 and 3.");
            }
        }
    }
    

    private static void searchByName() {
        System.out.println("Main Window -> Search for Contact window -> Search by Name:");
        System.out.println("===========================================================");
        System.out.print("Enter Name: ");
        String name = scanner.nextLine();
        displaySearchResults(name, "name");
    }

    private static void searchByEmail() {
        System.out.println("Main Window -> Search for Contact window -> Search by Email:");
        System.out.println("============================================================");
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        displaySearchResults(email, "email");
    }

    private static void searchByPhone() {
        System.out.println("Main Window -> Search for Contact window -> Search by Phone:");
        System.out.println("=============================================================");
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        displaySearchResults(phone, "phone");
    }

    private static void displaySearchResults(String query, String type) {
        ArrayList<Contact> results = new ArrayList<>();
        for (Contact contact : contacts) {
            if (type.equals("name") && contact.getName().toLowerCase().contains(query.toLowerCase()) ||
                type.equals("email") && contact.getEmail().equalsIgnoreCase(query) ||
                type.equals("phone") && contact.getPhone().equals(query)) {
                results.add(contact);
            }
        }
    
        if (results.isEmpty()) {
            System.out.println("No results found. Press Enter to go back.");
            scanner.nextLine();
            return;
        }
    
        // Display the table header
        System.out.printf("%-5s | %-20s | %-30s | %-15s | %-30s%n", "ID", "Name", "Email", "Phone", "Notes");
        System.out.println("-------------------------------------------------------------------------------------------");
    
        // Display found contacts
        for (Contact contact : results) {
            System.out.printf("%-5d | %-20s | %-30s | %-15s | %-30s%n", 
                              contact.getId(), 
                              contact.getName(), 
                              contact.getEmail(), 
                              contact.getPhone(), 
                              contact.getNotes());
        }
        System.out.println();
    
        // Actions
        System.out.println("Choose one of these options:");
        System.out.println("(1) To delete a contact");
        System.out.println("(2) Back to main Window");
        System.out.println();
        System.out.print("Enter Your Choice: ");
        
        int choice = scanner.nextInt();
        if (choice == 1) {
            System.out.print("Enter the Contact ID: ");
            int id = scanner.nextInt();
            deleteContactById(id);
            System.out.println("Deleted…press Enter to go back to main window");
            scanner.nextLine();
            scanner.nextLine();  // consume two newlines
        } else {
            scanner.nextLine();  // consume newline
        }
    }
    

    private static void deleteContactById(int id) {
        contacts.removeIf(contact -> contact.getId() == id);
    }

    private static void displayAllContacts() {
        if (contacts.isEmpty()) {
            System.out.println("Address Book is empty. Press Enter to go back.");
            scanner.nextLine();
            return;
        }
        System.out.println("\nMain Window --> Display All Contacts:");
        System.out.println("=========================================");
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.printf("%-5s | %-20s | %-30s | %-15s | %-30s%n", "ID", "Name", "Email", "Phone", "Notes");
        System.out.println("-------------------------------------------------------------------------------------------");
    
        // Display all contacts
        for (Contact contact : contacts) {
            System.out.printf("%-5d | %-20s | %-30s | %-15s | %-30s%n", 
                              contact.getId(), 
                              contact.getName(), 
                              contact.getEmail(), 
                              contact.getPhone(), 
                              contact.getNotes());
        }
        System.out.println();
        System.out.println("-------------------------------------------------------------------------------------------");
        System.out.println();
        System.out.println("\nPress Enter to go back.");
        scanner.nextLine();
    }
    
}


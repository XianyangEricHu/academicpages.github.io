#include <iostream>
#include <vector>
#include <ctime>
#include <iomanip>
#include <algorithm>
#include <cctype>

using namespace std;

class Transaction {
public:
    
    Transaction(const string& type, double amount) {
        this->type = type;
        this->amount = amount;

        time_t now = time(0);
        date = ctime(&now);
    }

    const string& getDate() const { return date; }
    const string& getType() const { return type; }
    double getAmount() const { return amount; }

private:
    string date;
    string type;
    double amount;
};

class BankAccount {
public:
    static int currentAccountNumber;  

    BankAccount(double balance, const string& password){
        accountNo = ++currentAccountNumber; 
        this->balance = balance;            
        this->password = password; 
    }

    int getAccountNo() const { return accountNo; }
    double getBalance() const { return balance; }

    bool verifyPassword(const string& pwd) const { 
        return pwd == password; 
    }

    //add funds
    void deposit(double amount) {
        balance += amount;
        transactions.push_back(Transaction("deposit", amount));
    }

    //deduct funds
    bool withdraw(double amount) {
        if(amount <= balance) {
            balance -= amount;
            transactions.push_back(Transaction("withdraw", amount));
            return true;
        }
        return false;
    }

    //a list of all the transactions
    const vector<Transaction>& getTransactions() const { return transactions; }

private:
    int accountNo;
    double balance;
    string password;
    vector<Transaction> transactions;  //list of all transactions for this account
};

int BankAccount::currentAccountNumber = 0;  //initialize the static member

void showMainMenu();
void handleShowBalance(BankAccount& account);
void handleDeposit(BankAccount& account);
void handleWithdraw(BankAccount& account);
void handleTransactions(BankAccount& account);
BankAccount* login(vector<BankAccount>& accounts);

int main() {
    vector<BankAccount> accounts;

    //initialize 10 accounts with 5000 balance and "123" password
    for(int i = 0; i < 10; i++) {
        accounts.push_back(BankAccount(5000, "123"));
    }

    BankAccount* loggedInAccount = nullptr;
    while(!(loggedInAccount = login(accounts))) {
        cout << "Invalid login. Try again.\n";
    }

    while(true) {
        showMainMenu();

        int choice;
        cin >> choice;
        cin.ignore();

        switch(choice) {
            case 1:
                handleShowBalance(*loggedInAccount);
                break;
            case 2:
                handleDeposit(*loggedInAccount);
                break;
            case 3:
                handleWithdraw(*loggedInAccount);
                break;
            case 4:
                handleTransactions(*loggedInAccount);
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    }

    return 0;
}

void showMainMenu() {
    cout << "Main Window\n";
    cout << "============\n";
    cout << "Choose one of the following options:\n";
    cout << "(1) Show balance\n";
    cout << "(2) Deposit\n";
    cout << "(3) Withdraw\n";
    cout << "(4) Show All Transactions\n";
    cout << "Enter Your Choice: ";
}

BankAccount* login(vector<BankAccount>& accounts) {
    cout << "Login Window:\n";
    cout << "=============\n";
    cout << "Enter Your Account No: ";
    int accountNo;
    cin >> accountNo;
    cout << "Enter Your Password: ";
    string password;
    cin >> password;
    cin.ignore();

    //check for a matching account number and password
    for(auto& account : accounts) {
        if(account.getAccountNo() == accountNo && account.verifyPassword(password)) {
            return &account;
        }
    }
    return nullptr;  //no match found
}

void handleShowBalance(BankAccount& account) {
    cout << "Main Window --> Show Balance\n";
    cout << "=======================================================\n";
    cout << "Your current balance is: $" << fixed << setprecision(2) << account.getBalance() << "\n";
    cout << "-------------------------------------------------------\n";
    cout << "Press Enter to get back to the Main Window\n";
    cin.ignore();
}

void handleDeposit(BankAccount& account) {
    double amount;
    cout << "Main Window --> Deposit (Enter the following information)\n";
    cout << "===============================================================\n";
    cout << "The amount you want to deposit: ";
    cin >> amount;
    cin.ignore();
    cout << "---------------------------------------------------------------\n";
    if(amount > 0) {
        account.deposit(amount);
        cout << "Well done. This was added to your balance successfully....Press Enter to go back to the Main Window.\n";
        cin.ignore();
    } else {
        cout << "Invalid amount! Press Enter to go back to the Main Window.\n";
        cin.ignore();
    }
}

void handleWithdraw(BankAccount& account) {
    double amount;
    cout << "Main Window --> Withdraw (Enter the following information)\n";
    cout << "===========================================================================\n";
    cout << "The amount you want to withdraw: ";
    cin >> amount;
    cin.ignore();
    cout << "---------------------------------------------------------------------------\n";

    if(account.withdraw(amount)) {
        cout << "Please take your money then....Press Enter to go back to the Main Window\n";
    } else {
        cout << "Insufficient funds or invalid amount! Press Enter to go back to the Main Window.\n";
    }
    cin.ignore();
}

string trim(const string &s) {
    auto wsfront = find_if_not(s.begin(), s.end(), ::isspace);
    auto wsback = find_if_not(s.rbegin(), s.rend(), ::isspace).base();
    return (wsback <= wsfront ? string() : string(wsfront, wsback));
}

void handleTransactions(BankAccount& account) {
    const int dateWidth = 30;    // Adjust these widths as needed
    const int typeWidth = 25;
    const int amountWidth = 10;

    cout << "Main Window --> Show All Transactions\n";
    cout << "===========================================================================\n";
    cout << "\n";
    cout << "Account no: " << account.getAccountNo() << "\n";
    cout << "---------------------------------------------------------------------\n";
    cout << left << setw(dateWidth) << "Date"
         << "| " << setw(typeWidth) << "Type"
         << "| " << setw(amountWidth) << "Amount" << "\n";
    cout << "---------------------------------------------------------------------\n";
    for(const auto& trans : account.getTransactions()) {
        string cleanedDate = trim(trans.getDate());
        cout << left << setw(dateWidth) << cleanedDate
             << "| " << setw(typeWidth) << trans.getType()
             << "| " << fixed << setprecision(2) << setw(amountWidth) << trans.getAmount() << "\n";
    }
    cout << "---------------------------------------------------------------------\n";
    cout << "Press Enter to go back to the Main Window\n";
    cin.ignore();
}